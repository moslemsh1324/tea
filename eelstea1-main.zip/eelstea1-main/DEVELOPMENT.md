# Local Development

## Requirements

Node: https://nodejs.org/en/download

## Install Dependencies

```shell
npm install
```

## Run Tests

To run all tests:

```shell
npm run test
```

To run individual tests:

```shell
npm run test -t transmission
```

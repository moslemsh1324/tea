# Reporting Security Issues

If you discover a security vulnerability, please open an issue with label `type: security`.
